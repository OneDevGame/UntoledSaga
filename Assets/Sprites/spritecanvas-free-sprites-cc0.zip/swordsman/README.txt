Moss swordsman - free sprite sheets (CC0)

A white-haired swordsman with a moss-green cloak: idle, run, jump, a three-hit sword combo and a ground-slam skill, facing right.

Sheets (8 frames per row, read left to right, top to bottom):
- swordsman-idle.png: 35 frames, 384x256 cells, 9 fps, loop, pivot 168,236
- swordsman-run.png: 9 frames, 384x256 cells, 12 fps, loop, pivot 168,236
- swordsman-jump.png: 21 frames, 384x256 cells, 14 fps, plays once, pivot 168,236
- swordsman-attack.png: 38 frames, 384x256 cells, 16 fps, plays once, pivot 168,236
- swordsman-skill.png: 25 frames, 384x256 cells, 16 fps, plays once, pivot 168,236

Each JSON file is a JSON Hash atlas: load it with Phaser's load.atlas or PixiJS Assets.
Frame durations are in milliseconds; pivot is the foot point, normalized to the cell.

Made with SpriteCanvas: https://spritecanvas.com/free-sprite-sheets/
