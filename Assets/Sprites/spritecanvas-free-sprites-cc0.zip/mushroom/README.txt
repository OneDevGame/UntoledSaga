Mushroom - free sprite sheets (CC0)

A walking mushroom: idle, hurt and death.

Sheets (8 frames per row, read left to right, top to bottom):
- mushroom-idle.png: 21 frames, 196x155 cells, 5 fps, loop, pivot 77,143
- mushroom-hurt.png: 11 frames, 196x155 cells, 18 fps, plays once, pivot 77,143
- mushroom-death.png: 17 frames, 196x155 cells, 16 fps, plays once, pivot 77,143

Each JSON file is a JSON Hash atlas: load it with Phaser's load.atlas or PixiJS Assets.
Frame durations are in milliseconds; pivot is the foot point, normalized to the cell.

Made with SpriteCanvas: https://spritecanvas.com/free-sprite-sheets/
