Goblin - free sprite sheets (CC0)

A goblin with a spiked club: idle, hurt and death.

Sheets (8 frames per row, read left to right, top to bottom):
- goblin-idle.png: 21 frames, 275x227 cells, 5 fps, loop, pivot 125,192
- goblin-hurt.png: 6 frames, 275x227 cells, 18 fps, plays once, pivot 125,192
- goblin-death.png: 19 frames, 275x227 cells, 14 fps, plays once, pivot 125,192

Each JSON file is a JSON Hash atlas: load it with Phaser's load.atlas or PixiJS Assets.
Frame durations are in milliseconds; pivot is the foot point, normalized to the cell.

Made with SpriteCanvas: https://spritecanvas.com/free-sprite-sheets/
