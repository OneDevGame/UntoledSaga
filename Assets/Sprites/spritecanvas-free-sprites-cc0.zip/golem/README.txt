Golem - free sprite sheets (CC0)

A stone golem: idle, hurt and death.

Sheets (8 frames per row, read left to right, top to bottom):
- golem-idle.png: 21 frames, 288x253 cells, 5 fps, loop, pivot 149,232
- golem-hurt.png: 5 frames, 288x253 cells, 15 fps, plays once, pivot 149,232
- golem-death.png: 24 frames, 288x253 cells, 15 fps, plays once, pivot 149,232

Each JSON file is a JSON Hash atlas: load it with Phaser's load.atlas or PixiJS Assets.
Frame durations are in milliseconds; pivot is the foot point, normalized to the cell.

Made with SpriteCanvas: https://spritecanvas.com/free-sprite-sheets/
