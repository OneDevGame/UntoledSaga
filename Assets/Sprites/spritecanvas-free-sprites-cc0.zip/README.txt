SpriteCanvas free sprite sheets (CC0)

Six characters and six effects, each move as a PNG sprite sheet with a JSON Hash atlas
(load it with Phaser's load.atlas or PixiJS Assets). Every folder has its own README with
frame counts, cell size, fps and the foot pivot.

- swordsman: idle, run, jump, attack, skill
- moss-knight: idle, walk, attack, roll, jump
- slime, mushroom, goblin, golem: idle, hurt, death
- effects: sword-slash, hit-spark, fireball, lightning, explosion, ice-burst

License: CC0 1.0 (see LICENSE.txt in each folder). Credit is welcome but not required.
The art was generated with AI in the SpriteCanvas workflow: https://spritecanvas.com/free-sprite-sheets/
