Slime - free sprite sheets (CC0)

A green slime: idle, hurt and death.

Sheets (8 frames per row, read left to right, top to bottom):
- slime-idle.png: 35 frames, 141x129 cells, 8 fps, loop, pivot 67,121
- slime-hurt.png: 8 frames, 141x129 cells, 16 fps, plays once, pivot 67,121
- slime-death.png: 21 frames, 141x129 cells, 14 fps, plays once, pivot 67,121

Each JSON file is a JSON Hash atlas: load it with Phaser's load.atlas or PixiJS Assets.
Frame durations are in milliseconds; pivot is the foot point, normalized to the cell.

Made with SpriteCanvas: https://spritecanvas.com/free-sprite-sheets/
