Effects pack 2 - free sprite sheets (CC0)

Ten 2D game effects, six frames each: heal, smoke puff, magic circle, poison cloud, shield bubble, tornado, water splash, holy light, dark orb and teleport. Pivot is the cell centre.

Sheets (8 frames per row, read left to right, top to bottom):
- effects-2-heal.png: 6 frames, 258x361 cells, 12 fps, plays once, pivot 129,180
- effects-2-smoke-puff.png: 6 frames, 367x362 cells, 12 fps, plays once, pivot 183,181
- effects-2-magic-circle.png: 6 frames, 382x368 cells, 12 fps, plays once, pivot 191,184
- effects-2-poison-cloud.png: 6 frames, 385x329 cells, 12 fps, plays once, pivot 192,164
- effects-2-shield-bubble.png: 6 frames, 341x345 cells, 12 fps, plays once, pivot 170,172
- effects-2-tornado.png: 6 frames, 365x353 cells, 12 fps, plays once, pivot 182,176
- effects-2-water-splash.png: 6 frames, 378x325 cells, 12 fps, plays once, pivot 189,162
- effects-2-holy-light.png: 6 frames, 313x368 cells, 12 fps, plays once, pivot 156,184
- effects-2-dark-orb.png: 6 frames, 334x331 cells, 12 fps, plays once, pivot 167,165
- effects-2-teleport.png: 6 frames, 330x361 cells, 12 fps, plays once, pivot 165,180

Each JSON file is a JSON Hash atlas: load it with Phaser's load.atlas or PixiJS Assets.
Frame durations are in milliseconds; pivot is the foot point, normalized to the cell.

Made with SpriteCanvas: https://spritecanvas.com/free-sprite-sheets/
